<template>
  <div class="home">
    <HeroBanner src="/images/actiportada.jpeg" />

    <!-- Sección principal -->
    <section
      class="section"
      v-animateonscroll="{ enterClass: 'fadeinup', leaveClass: 'fadeout' }"
    >
      <div class="content">
        <h2 class="title">¿Qué es <span class="brand">ActiVida</span>?</h2>
        <p class="subtitle">
          Somos más que un club de running. Somos una comunidad de
          transformación.
        </p>

        <div class="mvf-grid">
          <div class="mvf-card">
            <div class="mvf-header">
              <div class="mvf-icon mission">
                <i class="pi pi-bullseye"></i>
              </div>
              <h2>Nuestra Misión</h2>
            </div>
            <div class="mvf-body">
              <p>
                Crear un espacio donde cada corredor, sin importar su nivel,
                pueda desarrollarse de forma integral. No solo entrenamos
                atletas; formamos personas resilientes, disciplinadas y
                apasionadas que transforman sus vidas a través del running.
              </p>
              <div class="mvf-highlight">
                <strong>Apoyo 24/7</strong> de coaches certificados y una
                comunidad que te motiva en cada kilómetro.
              </div>
            </div>
          </div>

          <div class="mvf-card">
            <div class="mvf-header">
              <div class="mvf-icon vision">
                <i class="pi pi-eye"></i>
              </div>
              <h2>Nuestra Visión</h2>
            </div>
            <div class="mvf-body">
              <p>
                Ser el club de running más influyente en Latinoamérica,
                reconocido por producir atletas de élite y, sobre todo, por
                cambiar vidas a través del deporte. Queremos que ActiVida sea
                sinónimo de excelencia, inclusión e innovación en el running.
              </p>
              <div class="mvf-highlight">
                <strong>Eventos que nos unen</strong> y hacen que la comunidad
                crezca y se supere en cada experiencia.
              </div>
            </div>
          </div>

          <div class="mvf-card">
            <div class="mvf-header">
              <div class="mvf-icon philosophy">
                <i class="pi pi-heart"></i>
              </div>
              <h2>Nuestra Filosofía</h2>
            </div>
            <div class="mvf-body">
              <p>
                "Entrena para llegar bien, hábitos que duran." Creemos en el
                poder transformador del running combinado con disciplina,
                nutrición y mentalidad. Cada paso es progreso. Cada carrera es
                aprendizaje. Cada miembro es familia.
              </p>
              <div class="mvf-highlight">
                <strong>Personas como tú</strong> que decidieron ir por su mejor
                versión.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Sección de beneficios destacados -->
    <section
      class="benefits-section"
      v-animateonscroll="{ enterClass: 'fadeinup', leaveClass: 'fadeout' }"
    >
      <div class="content">
        <h2 class="section-title">¿Por qué unirse a ActiVida?</h2>

        <div class="benefits-grid">
          <div class="benefit-card">
            <div class="benefit-icon">
              <i class="pi pi-chart-line"></i>
            </div>
            <h3>Progreso Medible</h3>
            <p>Seguimiento detallado de tu rendimiento y mejora continua</p>
          </div>

          <div class="benefit-card">
            <div class="benefit-icon">
              <i class="pi pi-users"></i>
            </div>
            <h3>Comunidad Fuerte</h3>
            <p>Más de 100 corredores como tú compartiendo el mismo objetivo</p>
          </div>

          <div class="benefit-card">
            <div class="benefit-icon">
              <i class="pi pi-star"></i>
            </div>
            <h3>Experta Certificada</h3>
            <p>
              Entrenadora certificada <strong>NSCA-CPT</strong>, especialista en
              deportes de resistencia, psicología del deporte y rendimiento
              físico.
            </p>
            <p class="muted">
              Lic. en Cultura Física y Deporte · Mtra. en Ciencias de la
              Actividad Física y el Deporte
            </p>
          </div>

          <div class="benefit-card">
            <div class="benefit-icon">
              <i class="pi pi-bolt"></i>
            </div>
            <h3>Entrenamientos Variados</h3>
            <p>50+ entrenamientos diferentes cada mes adaptados a tu nivel</p>
          </div>

          <div class="benefit-card">
            <div class="benefit-icon">
              <i class="pi pi-check-circle"></i>
            </div>
            <h3>Planes Flexibles</h3>
            <p>Elige el plan que se adapte a tu ritmo y presupuesto</p>
          </div>

          <div class="benefit-card">
            <div class="benefit-icon">
              <i class="pi pi-heart"></i>
            </div>
            <h3>Apoyo Permanente</h3>
            <p>Soporte 24/7 para resolver tus dudas y motivarte</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Testimonios -->
    <!-- <section
      class="testimonials-section"
      v-animateonscroll="{ enterClass: 'fadeinup', leaveClass: 'fadeout' }"
    >
      <div class="content">
        <h2 class="section-title">Lo que dicen nuestros corredores</h2>

        <div class="testimonials-grid">
          <div class="testimonial-card">
            <div class="stars">★★★★★</div>
            <p>
              "ActiVida cambió completamente mi forma de entrenar. Los
              entrenamientos son personalizados y el coaching es excepcional."
            </p>
            <div class="testimonial-author">
              <div class="avatar">JC</div>
              <div>
                <h4>Juan Carlos</h4>
                <p>Corredor 5K</p>
              </div>
            </div>
          </div>

          <div class="testimonial-card">
            <div class="stars">★★★★★</div>
            <p>
              "La comunidad es lo mejor. Encontré gente con mis mismos objetivos
              y nos motivamos mutuamente cada día."
            </p>
            <div class="testimonial-author">
              <div class="avatar">MR</div>
              <div>
                <h4>María Rodríguez</h4>
                <p>Corredora de Maratón</p>
              </div>
            </div>
          </div>

          <div class="testimonial-card">
            <div class="stars">★★★★★</div>
            <p>
              "Pasé de no poder correr 1km a completar una maratón. ¡No lo
              habría logrado sin ActiVida!"
            </p>
            <div class="testimonial-author">
              <div class="avatar">CR</div>
              <div>
                <h4>Carlos Rivera</h4>
                <p>Atleta Trail</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section> -->

    <!-- CTA Principal -->
    <section
      class="section cta-section"
      v-animateonscroll="{ enterClass: 'fadein', leaveClass: 'fadeout' }"
    >
      <div class="content center">
        <h2 class="title">¿List@ para empezar?</h2>
        <p class="subtitle">
          Transforma tu pasión por el running en una realidad. Únete a ActiVida
          hoy.
        </p>

        <div class="cta-buttons">
          <Button
            label="Ver Planes"
            icon="pi pi-list"
            @click="goToPlans"
            class="cta-btn-primary"
          />
          <Button
            label="Contactar por WhatsApp"
            icon="pi pi-whatsapp"
            severity="success"
            @click="goToWhatsApp"
            class="cta-btn-secondary"
          />
        </div>
      </div>
    </section>

    <!-- FAQ Section -->
    <section
      class="faq-section"
      v-animateonscroll="{ enterClass: 'fadeinup', leaveClass: 'fadeout' }"
    >
      <div class="content">
        <h2 class="section-title">Preguntas Frecuentes</h2>

        <Accordion :value="0">
          <AccordionTab header="¿Cuál es el nivel mínimo para unirme?">
            <p>
              ActiVida es para corredores de TODOS los niveles. Tenemos
              entrenamientos desde principiante hasta avanzado. No importa si
              apenas empiezas o si ya corres maratones.
            </p>
          </AccordionTab>
          <AccordionTab header="¿Puedo cambiar de plan en cualquier momento?">
            <p>
              Sí, puedes cambiar, mejorar o cancelar tu plan cuando lo desees.
              Queremos que estés cómodo con tu elección.
            </p>
          </AccordionTab>
          <AccordionTab header="¿Qué incluye el coaching personalizado?">
            <p>
              Planes de entrenamiento adaptados a tu nivel, análisis de tu
              técnica de carrera, nutrición deportiva y soporte emocional para
              alcanzar tus metas.
            </p>
          </AccordionTab>
          <AccordionTab header="¿Cuándo puedo empezar?">
            <p>
              ¡Ahora mismo! Contáctanos por WhatsApp y comenzarás tu
              transformación en 48 horas. Nuestro equipo te apoyará en cada
              paso.
            </p>
          </AccordionTab>
        </Accordion>
      </div>
    </section>
  </div>
</template>

<script setup>
import { useRouter } from "vue-router";
import HeroBanner from "../components/home/HeroBanner.vue";
import Button from "primevue/button";
import Accordion from "primevue/accordion";
import AccordionTab from "primevue/accordiontab";

const router = useRouter();

const goToPlans = () => router.push("/planes");

const goToWhatsApp = () => {
  window.open("https://wa.me/524491004396", "_blank");
};
</script>

<style scoped>
.home {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 0;
  background: var(--surface-ground);
  color: var(--text-color);
}

/* Stats Banner */
.stats-banner {
  background: linear-gradient(135deg, #2ee56f15, transparent);
  padding: 3rem 1rem;
  border-bottom: 1px solid var(--surface-border);
}

.stats-content {
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
  text-align: center;
}

.stat-item h3 {
  margin: 0;
  font-size: 32px;
  color: #2ee56f;
  font-weight: 700;
}

.stat-item p {
  margin: 0.5rem 0 0;
  color: var(--text-color-secondary);
  font-size: 14px;
}

/* Sections */
.section {
  padding: 3rem 1rem;
}

.content {
  max-width: 1100px;
  margin: 0 auto;
}

.center {
  text-align: center;
}

.title {
  font-size: clamp(28px, 5vw, 44px);
  font-weight: 800;
  margin: 0 0 0.5rem;
}

.subtitle {
  margin-top: 1rem;
  color: var(--text-color-secondary);
  font-size: 18px;
  line-height: 1.6;
}

.brand {
  color: var(--primary-color);
}

.card {
  background: var(--surface-card);
  border: 1px solid var(--surface-border);
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
  height: 100%;
}

.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 24px rgba(46, 229, 111, 0.12);
  border-color: #2ee56f;
}

.card-icon {
  width: 50px;
  height: 50px;
  background: linear-gradient(135deg, #2ee56f20, #26c95f20);
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #2ee56f;
}

.hero__brand {
  color: #2ee56f;
  font-weight: 700;
}

/* MVF (Misión, Visión, Filosofía) Section */
.mvf-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 2.5rem;
  margin-top: 3rem;
}

.mvf-card {
  background: var(--surface-card);
  border: 2px solid var(--surface-border);
  border-radius: 16px;
  overflow: hidden;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  height: 100%;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
}

.mvf-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 40px rgba(46, 229, 111, 0.15);
  border-color: #2ee56f;
}

.mvf-header {
  padding: 2.5rem 2rem 1.5rem;
  border-bottom: 2px solid var(--surface-border);
  display: flex;
  align-items: flex-start;
  gap: 1.5rem;
}

.mvf-icon {
  width: 70px;
  height: 70px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32px;
  flex-shrink: 0;
}

.mvf-icon.mission {
  background: linear-gradient(135deg, #ff6b6b20, #ff5252);
  color: #ff5252;
}

.mvf-icon.vision {
  background: linear-gradient(135deg, #4ecdc420, #4ecdc4);
  color: #4ecdc4;
}

.mvf-icon.philosophy {
  background: linear-gradient(135deg, #2ee56f20, #2ee56f);
  color: #2ee56f;
}

.mvf-header h2 {
  margin: 0;
  font-size: 24px;
  font-weight: 800;
}

.mvf-body {
  padding: 2rem;
  display: flex;
  flex-direction: column;
  flex: 1;
}

.mvf-body p {
  margin: 0 0 1.5rem;
  font-size: 15px;
  line-height: 1.8;
  color: var(--text-color);
}

.mvf-highlight {
  background: linear-gradient(
    135deg,
    var(--surface-ground),
    var(--surface-border)
  );
  border-left: 4px solid #2ee56f;
  padding: 1rem 1rem 1rem 1.25rem;
  border-radius: 8px;
  font-size: 14px;
  color: var(--text-color);
  margin-top: auto;
}

.mvf-highlight strong {
  color: #2ee56f;
}

/* Benefits Section */
.benefits-section {
  background: var(--surface-card);
  padding: 4rem 1rem;
}

.benefits-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 2rem;
  margin-top: 2rem;
}

.benefit-card {
  background: var(--surface-ground);
  padding: 2rem 1.5rem;
  border-radius: 12px;
  border: 1px solid var(--surface-border);
  text-align: center;
  transition: all 0.3s ease;
}

.benefit-card:hover {
  transform: translateY(-4px);
  border-color: #2ee56f;
  box-shadow: 0 12px 24px rgba(46, 229, 111, 0.12);
}

.benefit-icon {
  font-size: 32px;
  color: #2ee56f;
  margin-bottom: 1rem;
}

.benefit-card h3 {
  margin: 0 0 0.75rem;
  font-size: 18px;
  font-weight: 700;
}

.benefit-card p {
  margin: 0;
  color: var(--text-color-secondary);
  font-size: 14px;
  line-height: 1.5;
}

/* Testimonials 
.testimonials-section {
  padding: 4rem 1rem;
}

.testimonials-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  margin-top: 2rem;
}

.testimonial-card {
  background: var(--surface-card);
  padding: 2rem;
  border-radius: 12px;
  border: 1px solid var(--surface-border);
  transition: all 0.3s ease;
}

.testimonial-card:hover {
  border-color: #2ee56f;
  box-shadow: 0 12px 24px rgba(46, 229, 111, 0.12);
}

.stars {
  color: #ffc107;
  font-size: 18px;
  margin-bottom: 1rem;
}

.testimonial-card p {
  color: var(--text-color-secondary);
  font-size: 15px;
  line-height: 1.6;
  margin: 0 0 1.5rem;
  font-style: italic;
}

.testimonial-author {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.avatar {
  width: 48px;
  height: 48px;
  background: linear-gradient(135deg, #2ee56f, #26c95f);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: 700;
  font-size: 14px;
}

.testimonial-author h4 {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
}

.testimonial-author p {
  margin: 0;
  color: var(--text-color-secondary);
  font-size: 13px;
  font-style: normal;
}
*/
/* CTA Section */
.cta-section {
  background: linear-gradient(135deg, #2ee56f15, transparent);
  border-top: 2px solid #2ee56f30;
  border-bottom: 2px solid #2ee56f30;
}

.cta-buttons {
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
  margin-top: 2rem;
}

:deep(.cta-btn-primary) {
  background: linear-gradient(135deg, #2ee56f, #26c95f) !important;
  border: none !important;
  color: #000 !important;
  padding: 12px 40px !important;
  font-weight: 600 !important;
  border-radius: 8px !important;
}

:deep(.cta-btn-primary:hover) {
  transform: translateY(-2px);
  box-shadow: 0 12px 24px rgba(46, 229, 111, 0.3) !important;
}

/* FAQ Section */
.faq-section {
  padding: 4rem 1rem;
  background: var(--surface-card);
}

.section-title {
  font-size: 32px;
  font-weight: 800;
  text-align: center;
  margin-bottom: 2rem;
}

:deep(.p-accordion) {
  max-width: 800px;
  margin: 0 auto;
}

:deep(.p-accordion .p-accordion-header-link) {
  padding: 1.5rem;
  font-weight: 600;
}

/* Grid utilities */
.grid {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 1.5rem;
}

.col-12 {
  grid-column: span 12;
}

@media (min-width: 768px) {
  .col-12.md\:col-4 {
    grid-column: span 4;
  }
}

.mt-5 {
  margin-top: 2rem;
}

.p-4 {
  padding: 1.5rem;
}

.font-semibold {
  font-weight: 600;
}

.text-color-secondary {
  color: var(--text-color-secondary);
}

@media (max-width: 1024px) {
  .section {
    padding: 3rem 1rem;
  }

  .mvf-grid {
    gap: 2rem;
  }

  .benefits-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .testimonials-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .title {
    font-size: clamp(24px, 4vw, 36px);
  }
}

@media (max-width: 768px) {
  .section {
    padding: 2rem 1rem;
  }

  .mvf-grid {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }

  .mvf-header {
    flex-direction: column;
    align-items: center;
    text-align: center;
    padding: 2rem 1.5rem 1rem;
  }

  .mvf-icon {
    width: 60px;
    height: 60px;
    font-size: 28px;
  }

  .benefits-grid {
    grid-template-columns: 1fr;
  }

  .benefit-card {
    padding: 1.5rem 1rem;
  }

  .testimonials-grid {
    grid-template-columns: 1fr;
  }

  .cta-buttons {
    flex-direction: column;
    gap: 0.75rem;
  }

  :deep(.cta-btn-primary),
  :deep(.cta-btn-secondary) {
    width: 100%;
  }

  .title {
    font-size: clamp(20px, 3vw, 28px);
  }

  .subtitle {
    font-size: 16px;
  }

  .section-title {
    font-size: 24px;
  }

  .stats-content {
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
  }

  .stat-item h3 {
    font-size: 24px;
  }

  .stat-item p {
    font-size: 12px;
  }

  :deep(.p-accordion .p-accordion-header-link) {
    padding: 1rem;
    font-size: 14px;
  }
}

@media (max-width: 480px) {
  .section {
    padding: 1.5rem 0.75rem;
  }

  .content {
    padding: 0 0.5rem;
  }

  .title {
    font-size: 20px;
    margin-bottom: 0.75rem;
  }

  .subtitle {
    font-size: 14px;
  }

  .section-title {
    font-size: 20px;
    margin-bottom: 1rem;
  }

  .mvf-body {
    padding: 1.5rem 1rem;
  }

  .mvf-body p {
    font-size: 14px;
    line-height: 1.6;
  }

  .benefit-card {
    padding: 1rem 0.75rem;
  }

  .benefit-card h3 {
    font-size: 16px;
    margin-bottom: 0.5rem;
  }

  .benefit-card p {
    font-size: 13px;
  }

  .benefit-icon {
    font-size: 28px;
  }

  .testimonial-card {
    padding: 1.5rem 1rem;
  }

  .testimonial-card p {
    font-size: 14px;
  }

  .stats-content {
    grid-template-columns: 1fr;
    gap: 0.75rem;
  }

  .stat-item h3 {
    font-size: 20px;
  }

  .stat-item p {
    font-size: 11px;
  }

  .cta-buttons {
    gap: 0.5rem;
  }

  .mvf-highlight {
    padding: 0.75rem 0.75rem 0.75rem 1rem;
    font-size: 13px;
  }
}
</style>
