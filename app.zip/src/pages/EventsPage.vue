<template>
  <div class="events-page">
    <!-- Header -->
    <section class="events-header">
      <div class="header-content content">
        <div class="header-text">
          <h1>Eventos y Entrenamientos</h1>
          <p>Únete a la comunidad ActiVida en entrenamientos, carreras y eventos.</p>

          <!-- ✅ Horarios fijos de reunión -->
          <div class="meetups">
            <h2>Nos reunimos</h2>
            <ul>
              <li><strong>Martes 19:15</strong> · Pista IDEA o UAA</li>
              <li><strong>Jueves 18:30</strong> · Gómez Morín o Canal Interceptor</li>
              <li><strong>Domingo</strong> · Salidas a lugares de terracería</li>
            </ul>
          </div>
        </div>

        <img class="header-visual" :src="actividaCerebro" alt="ActiVida" />
      </div>
    </section>

    <!-- Search -->
    <section class="filters-section">
      <div class="content">
        <InputGroup class="search-bar">
          <InputGroupAddon>
            <i class="pi pi-search"></i>
          </InputGroupAddon>
          <InputText
            v-model="searchQuery"
            placeholder="Busca por evento, mes, ciudad o tipo (maratón, trail, etc.)..."
          />
        </InputGroup>

        <!-- Chips SOLO para estado, sin niveles -->
        <div class="filter-chips">
          <Chip
            v-for="s in ['Todos', 'Confirmados', 'Posibles']"
            :key="s"
            :label="s"
            :class="{ active: selectedStatus === s }"
            @click="selectedStatus = s"
          />
        </div>
      </div>
    </section>

    <!-- Grid -->
    <section class="events-grid">
      <div class="content">
        <div v-if="filteredEvents.length" class="events-list">
          <article v-for="event in filteredEvents" :key="event.id" class="event-card">
            <!-- ✅ Imagen con lazy (mejor que background-image) -->
            <div class="event-image">
              <img
                :src="event.image"
                :alt="event.title"
                loading="lazy"
                decoding="async"
                @error="onImgError"
              />
              <div class="event-category">{{ event.category }}</div>
              <div v-if="event.status === 'posible'" class="event-badge">FECHA POR CONFIRMAR</div>
            </div>

            <div class="event-content">
              <h3>{{ event.title }}</h3>
              <p class="event-desc">{{ event.description }}</p>

              <div class="event-meta">
                <div class="meta-item">
                  <i class="pi pi-calendar"></i>
                  <span>{{ event.dateLabel }}</span>
                </div>
                <div class="meta-item">
                  <i class="pi pi-map-marker"></i>
                  <span>{{ event.location }}</span>
                </div>
              </div>

              <div class="event-footer">
                <!-- ✅ Sin “GRATIS” -->
                <span v-if="event.price > 0" class="price">${{ event.price }}</span>
                <span v-else class="price muted">Costo por confirmar</span>

                <Button
                  label="Ver Detalles"
                  severity="success"
                  class="event-btn"
                  @click="viewEvent(event)"
                />
              </div>
            </div>
          </article>
        </div>

        <div v-else class="no-events">
          <i class="pi pi-inbox"></i>
          <p>No hay eventos que coincidan con tu búsqueda</p>
        </div>
      </div>
    </section>

    <!-- Destacados -->
    <section class="featured-events">
      <div class="content">
        <h2>Próximos Eventos Destacados</h2>

        <div class="carousel">
          <div v-for="event in featuredEvents" :key="event.id" class="carousel-item">
            <div class="featured-card" @click="viewEvent(event)">
              <img :src="event.image" :alt="event.title" loading="lazy" decoding="async" @error="onImgError" />
              <div class="featured-overlay">
                <h4>{{ event.title }}</h4>
                <p>{{ event.dateLabel }}</p>
                <Button label="Inscribirme" severity="success" size="small" @click.stop="viewEvent(event)" />
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, computed } from "vue";
import Button from "primevue/button";
import InputText from "primevue/inputtext";
import InputGroup from "primevue/inputgroup";
import InputGroupAddon from "primevue/inputgroupaddon";
import Chip from "primevue/chip";
import actividaCerebro from "../assets/actividacerebro.jpeg";

/**
 * ✅ Formateador (una vez)
 */
const dtf = new Intl.DateTimeFormat("es-MX", {
  weekday: "short",
  year: "numeric",
  month: "short",
  day: "numeric",
});

const searchQuery = ref("");
const selectedStatus = ref("Todos");

/**
 * Utils
 */
const makeDate = (y, mIndex, day) => new Date(y, mIndex, day, 7, 0);
const placeholder = (text) =>
  `https://via.placeholder.com/1200x675/0f172a/2ee56f?text=${encodeURIComponent(text)}`;

const buildEvent = ({
  id,
  title,
  date,
  location = "Por confirmar",
  category = "Carrera",
  description = "",
  price = 0,
  status = "confirmado", // confirmado | posible
  image,
}) => {
  const img = image || placeholder(title);
  const desc = description || `Evento: ${title}.`;
  const dateLabel = dtf.format(date);

  // ✅ texto precalculado para búsqueda rápida
  const searchText = [title, desc, category, location, status, dateLabel].join(" ").toLowerCase();

  return {
    id,
    title,
    description: desc,
    date,
    dateLabel,
    location,
    category,
    price,
    status,
    image: img,
    searchText,
  };
};

/**
 * ✅ Eventos 2026 (puedes seguir agregando los tuyos aquí)
 * Mes en JS: 0=Enero ... 11=Diciembre
 */
let id = 1;

const events = ref([
  // ===== ENERO =====
  buildEvent({ id: id++, title: "Carrera de la Divina Providencia", date: makeDate(2026, 0, 1), category: "Carrera", location: "Por confirmar" }),
  buildEvent({ id: id++, title: "Maratón Walt Disney", date: makeDate(2026, 0, 9), category: "Maratón", location: "Orlando, USA" }),
  buildEvent({ id: id++, title: "Maratón Dolores Hidalgo", date: makeDate(2026, 0, 11), category: "Maratón", location: "Dolores Hidalgo, GTO" }),
  buildEvent({ id: id++, title: "Maratón de Culiacán", date: makeDate(2026, 0, 18), category: "Maratón", location: "Culiacán, SIN" }),
  buildEvent({ id: id++, title: "Maratón Cabo San Lucas", date: makeDate(2026, 0, 18), category: "Maratón", location: "Cabo San Lucas, BCS" }),
  buildEvent({ id: id++, title: "Trail Villa del Carbón", date: makeDate(2026, 0, 23), category: "Trail", location: "Villa del Carbón, EDOMEX", description: "Evento (23–24)." }),
  buildEvent({ id: id++, title: "Ultra Bosque La Primavera", date: makeDate(2026, 0, 25), category: "Ultra", location: "Bosque La Primavera, JAL" }),
  buildEvent({ id: id++, title: "Medio Maratón Puerto de Veracruz", date: makeDate(2026, 0, 25), category: "Medio Maratón", location: "Veracruz, VER" }),
  buildEvent({ id: id++, title: "Juntos por Apali – Pabellón de Arteaga", date: makeDate(2026, 0, 25), category: "Carrera", location: "Pabellón de Arteaga, AGS" }),

  // ===== FEBRERO =====
  buildEvent({ id: id++, title: "HYROX Guadalajara", date: makeDate(2026, 1, 7), category: "HYROX", location: "Guadalajara, JAL", description: "Evento (07–08)." }),
  buildEvent({ id: id++, title: "Carrera de los Barrios", date: makeDate(2026, 1, 8), category: "Carrera", location: "León, GTO" }),
  buildEvent({ id: id++, title: "Ruta San Blas – Pabellón de Hidalgo", date: makeDate(2026, 1, 15), category: "Carrera", location: "Pabellón de Hidalgo, AGS" }),
  buildEvent({ id: id++, title: "Maratón Capital", date: makeDate(2026, 1, 15), category: "Maratón", location: "Guanajuato, GTO" }),
  buildEvent({ id: id++, title: "Trail Desafío en las Nubes", date: makeDate(2026, 1, 21), category: "Trail", location: "Puebla", description: "Evento (21–22)." }),
  buildEvent({ id: id++, title: "Rock 'n' Roll Las Vegas", date: makeDate(2026, 1, 22), category: "Carrera", location: "Las Vegas, USA" }),
  buildEvent({ id: id++, title: "Medio Maratón Guadalajara", date: makeDate(2026, 1, 22), category: "Medio Maratón", location: "Guadalajara, JAL" }),
  buildEvent({ id: id++, title: "Maratón del Desierto", date: makeDate(2026, 1, 22), category: "Maratón", location: "Por confirmar" }),

  // ===== MARZO =====
  buildEvent({ id: id++, title: "Medio Maratón Cancún", date: makeDate(2026, 2, 1), category: "Medio Maratón", location: "Cancún, QROO" }),
  buildEvent({ id: id++, title: "Ironman 70.3 Monterrey", date: makeDate(2026, 2, 1), category: "Ironman", location: "Monterrey, NL" }),
  buildEvent({ id: id++, title: "Maratón Lala – Torreón", date: makeDate(2026, 2, 1), category: "Maratón", location: "Torreón, COAH" }),
  buildEvent({ id: id++, title: "Puerto Vallarta by UTM", date: makeDate(2026, 2, 5), category: "UTM", location: "Puerto Vallarta, JAL", description: "Evento (05–07)." }),
  buildEvent({ id: id++, title: "Carrera de la Mujer", date: makeDate(2026, 2, 8), category: "Carrera", location: "Por confirmar" }),
  buildEvent({ id: id++, title: "HYROX Cancún", date: makeDate(2026, 2, 14), category: "HYROX", location: "Cancún, QROO", description: "Evento (14–15)." }),
  buildEvent({ id: id++, title: "Carrera de Teotihuacán 3K/5K/10K", date: makeDate(2026, 2, 15), category: "Carrera", location: "Teotihuacán, EDOMEX" }),
  buildEvent({ id: id++, title: "Carrera de Teotihuacán 21K", date: makeDate(2026, 2, 15), category: "Medio Maratón", location: "Teotihuacán, EDOMEX" }),
  buildEvent({ id: id++, title: "Medio Maratón San Diego", date: makeDate(2026, 2, 22), category: "Medio Maratón", location: "San Diego, CA, USA" }),

  // ===== ABRIL =====
  buildEvent({ id: id++, title: "Gran Fondo Rivera Nayarit", date: makeDate(2026, 3, 18), category: "Gran Fondo", location: "Nayarit" }),
  buildEvent({ id: id++, title: "HYROX Monterrey", date: makeDate(2026, 3, 18), category: "HYROX", location: "Monterrey, NL", description: "Evento (18–19)." }),
  buildEvent({ id: id++, title: "Maratón Puerto Vallarta", date: makeDate(2026, 3, 19), category: "Maratón", location: "Puerto Vallarta, JAL" }),
  buildEvent({ id: id++, title: "Medio Maratón BJX – León", date: makeDate(2026, 3, 26), category: "Medio Maratón", location: "León, GTO" }),

  // ===== MAYO =====
  buildEvent({ id: id++, title: "Ultra Otomí – Isidro Fabela", date: makeDate(2026, 4, 15), category: "Ultra", location: "Isidro Fabela, EDOMEX", description: "Evento (15–16)." }),
  buildEvent({ id: id++, title: "Medio Maratón Zapopan", date: makeDate(2026, 4, 17), category: "Medio Maratón", location: "Zapopan, JAL" }),
  buildEvent({ id: id++, title: "HYROX Puebla", date: makeDate(2026, 4, 23), category: "HYROX", location: "Puebla", description: "Evento (23–24)." }),
  buildEvent({ id: id++, title: "Rock 'n' Roll San Diego", date: makeDate(2026, 4, 31), category: "Carrera", location: "San Diego, CA, USA" }),
  // Posible / fecha por confirmar (barra de Mayo)
  buildEvent({ id: id++, title: "Carrera de San Marcos", date: makeDate(2026, 4, 15), category: "Carrera", location: "Aguascalientes, AGS", status: "posible" }),

  // ===== JUNIO =====
  buildEvent({ id: id++, title: "Triatlón Sprint Boca del Río", date: makeDate(2026, 5, 21), category: "Triatlón", location: "Boca del Río, VER" }),
  buildEvent({ id: id++, title: "Carrera del Día del Padre 21K", date: makeDate(2026, 5, 21), category: "21K", location: "CDMX" }),
  buildEvent({ id: id++, title: "Maratón Tangamanga", date: makeDate(2026, 5, 28), category: "Maratón", location: "San Luis Potosí, SLP" }),
  // Posibles / fecha por confirmar (barra de Junio)
  buildEvent({ id: id++, title: "Trail de la Mixteca Oaxaqueña", date: makeDate(2026, 5, 15), category: "Trail", location: "Oaxaca", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Peñuelas", date: makeDate(2026, 5, 15), category: "Carrera", location: "Peñuelas, AGS", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Medio Ambiente", date: makeDate(2026, 5, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Nike Women", date: makeDate(2026, 5, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),

  // ===== JULIO =====
  buildEvent({ id: id++, title: "Medio Maratón Ciudad de México", date: makeDate(2026, 6, 12), category: "Medio Maratón", location: "CDMX" }),
  buildEvent({ id: id++, title: "Ultra Coahuila", date: makeDate(2026, 6, 25), category: "Ultra", location: "Coahuila", description: "Evento (25–26)." }),
  buildEvent({ id: id++, title: "Triatlón Ciudad de México", date: makeDate(2026, 6, 25), category: "Triatlón", location: "CDMX", description: "Evento (25–26)." }),

  // ===== AGOSTO =====
  buildEvent({ id: id++, title: "Triatlón Veracruz – Boca del Río", date: makeDate(2026, 7, 22), category: "Triatlón", location: "Boca del Río, VER" }),
  buildEvent({ id: id++, title: "Trail La Bastarda", date: makeDate(2026, 7, 29), category: "Trail", location: "León, GTO" }),
  buildEvent({ id: id++, title: "Maratón Ciudad de México", date: makeDate(2026, 7, 30), category: "Maratón", location: "CDMX" }),
  // Posibles / fecha por confirmar (barra de Agosto)
  buildEvent({ id: id++, title: "Virgen de la Asunción", date: makeDate(2026, 7, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera de Uvas", date: makeDate(2026, 7, 15), category: "Carrera", location: "Cosío, AGS", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera de Huevos", date: makeDate(2026, 7, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Lancera", date: makeDate(2026, 7, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Race Fest 2", date: makeDate(2026, 7, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera de Colores", date: makeDate(2026, 7, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Runnract", date: makeDate(2026, 7, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Medio Maratón Atlas Colomos", date: makeDate(2026, 7, 15), category: "Medio Maratón", location: "Guadalajara, JAL", status: "posible" }),
  buildEvent({ id: id++, title: "Trail Ultra Sierra del Laurel", date: makeDate(2026, 7, 15), category: "Trail", location: "Calvillo, AGS", status: "posible" }),

  // ===== SEPTIEMBRE =====
  buildEvent({ id: id++, title: "Maratón de Berlín", date: makeDate(2026, 8, 27), category: "Maratón", location: "Berlín, Alemania" }),
  // Posibles / fecha por confirmar (barra de Septiembre)
  buildEvent({ id: id++, title: "Carrera Skarch", date: makeDate(2026, 8, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Cruz Roja", date: makeDate(2026, 8, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera UAA", date: makeDate(2026, 8, 15), category: "Carrera", location: "Aguascalientes, AGS", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Esperanza de un Nuevo Hogar", date: makeDate(2026, 8, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Pro Salud Mental", date: makeDate(2026, 8, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),

  // ===== OCTUBRE =====
  buildEvent({ id: id++, title: "Maratón Chicago", date: makeDate(2026, 9, 11), category: "Maratón", location: "Chicago, USA" }),
  buildEvent({ id: id++, title: "Maratón Aguascalientes", date: makeDate(2026, 9, 25), category: "Maratón", location: "Aguascalientes, AGS" }),
  // Posibles / fecha por confirmar (barra de Octubre)
  buildEvent({ id: id++, title: "Carrera Nissan", date: makeDate(2026, 9, 15), category: "Carrera", location: "Aguascalientes, AGS", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera del Médico", date: makeDate(2026, 9, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Ironman 70.3 Los Cabos", date: makeDate(2026, 9, 15), category: "Ironman", location: "Los Cabos, BCS", status: "posible" }),
  buildEvent({ id: id++, title: "Maratón de Querétaro", date: makeDate(2026, 9, 15), category: "Maratón", location: "Querétaro, QRO", status: "posible" }),

  // ===== NOVIEMBRE =====
  buildEvent({ id: id++, title: "Maratón Nueva York", date: makeDate(2026, 10, 1), category: "Maratón", location: "Nueva York, USA" }),
  buildEvent({ id: id++, title: "Ironman Cozumel", date: makeDate(2026, 10, 22), category: "Ironman", location: "Cozumel, QROO" }),
  // Posibles / fecha por confirmar (barra de Noviembre)
  buildEvent({ id: id++, title: "Maratón Pacífico Mazatlán", date: makeDate(2026, 10, 15), category: "Maratón", location: "Mazatlán, SIN", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Exalumnos UNAM", date: makeDate(2026, 10, 15), category: "Carrera", location: "CDMX", status: "posible" }),

  // ===== DICIEMBRE =====
  buildEvent({ id: id++, title: "Maratón Guadalupano", date: makeDate(2026, 11, 12), category: "Maratón", location: "Por confirmar" }),
  // Posibles / fecha por confirmar (barra de Diciembre)
  buildEvent({ id: id++, title: "Maratón de Monterrey", date: makeDate(2026, 11, 15), category: "Maratón", location: "Monterrey, NL", status: "posible" }),
  buildEvent({ id: id++, title: "Maratón Valencia", date: makeDate(2026, 11, 15), category: "Maratón", location: "Valencia, España", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Neón", date: makeDate(2026, 11, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera de Mar a Mar", date: makeDate(2026, 11, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Universidad Panamericana", date: makeDate(2026, 11, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Pedro Lomelí", date: makeDate(2026, 11, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
  buildEvent({ id: id++, title: "Carrera Adidas", date: makeDate(2026, 11, 15), category: "Carrera", location: "Por confirmar", status: "posible" }),
]);

// ordena una vez
events.value.sort((a, b) => a.date - b.date);

/**
 * ✅ Destacados: próximos 6 desde HOY (para que tenga sentido todo el año)
 */
const featuredEvents = computed(() => {
  const now = new Date();
  return events.value
    .filter((e) => e.date >= new Date(now.getFullYear(), now.getMonth(), now.getDate()))
    .slice(0, 6);
});

/**
 * ✅ Filtro: búsqueda + estado
 */
const filteredEvents = computed(() => {
  const q = searchQuery.value.trim().toLowerCase();
  const status = selectedStatus.value;

  return events.value.filter((e) => {
    const matchesSearch = !q || e.searchText.includes(q);

    const matchesStatus =
      status === "Todos"
        ? true
        : status === "Confirmados"
          ? e.status === "confirmado"
          : e.status === "posible";

    return matchesSearch && matchesStatus;
  });
});

/**
 * ✅ Fallback de imagen
 */
const onImgError = (ev) => {
  ev.target.src = placeholder("ActiVida");
};

/**
 * CTA WhatsApp
 */
const viewEvent = (event) => {
  const message =
    `Hola 👋 Me interesa este evento:\n` +
    `• ${event.title}\n` +
    `• ${event.dateLabel}\n` +
    `• ${event.location}\n` +
    `¿Me pueden compartir link de inscripción y costos?`;

  window.open(`https://wa.me/524491004396?text=${encodeURIComponent(message)}`, "_blank");
};
</script>

<style scoped>
.events-page {
  background: var(--surface-ground);
  color: var(--text-color);
  padding: 3rem 1rem 2rem;
  min-height: calc(100vh - 80px);
}

/* Header */
.events-header {
  margin-bottom: 2rem;
}
.header-content {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 1.5rem;
  align-items: center;
}
.header-text h1 {
  font-size: clamp(28px, 4.5vw, 46px);
  font-weight: 800;
  margin: 0 0 0.5rem;
}
.header-text p {
  margin: 0 0 1rem;
  color: var(--text-color-secondary);
  font-size: 16px;
}
.header-visual {
  width: 120px;
  height: auto;
  border-radius: 12px;
  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
}

.meetups {
  background: var(--surface-card);
  border: 1px solid var(--surface-border);
  border-radius: 12px;
  padding: 1rem 1.1rem;
}
.meetups h2 {
  margin: 0 0 0.75rem;
  font-size: 16px;
  font-weight: 800;
}
.meetups ul {
  margin: 0;
  padding-left: 1.1rem;
  color: var(--text-color-secondary);
  line-height: 1.7;
}

/* Layout */
.content {
  max-width: 1200px;
  margin: 0 auto;
}

.filters-section {
  margin-bottom: 2rem;
}

.search-bar {
  margin-bottom: 1rem;
}

.search-bar :deep(.p-input-group > input) {
  border-radius: 10px;
  padding: 12px 16px;
}

.filter-chips {
  display: flex;
  gap: 0.75rem;
  flex-wrap: wrap;
}

.filter-chips :deep(.p-chip) {
  cursor: pointer;
  transition: all 0.25s ease;
  background: var(--surface-card);
}

.filter-chips :deep(.p-chip.active) {
  background: #2ee56f !important;
  color: #000 !important;
}

/* Grid */
.events-grid {
  margin-bottom: 3rem;
}

.events-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(330px, 1fr));
  gap: 1.5rem;
}

.event-card {
  background: var(--surface-card);
  border: 1px solid var(--surface-border);
  border-radius: 14px;
  overflow: hidden;
  transition: all 0.25s ease;
  display: flex;
  flex-direction: column;
}
.event-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 16px 40px rgba(46, 229, 111, 0.12);
  border-color: #2ee56f;
}

.event-image {
  height: 190px;
  position: relative;
  overflow: hidden;
  background: #0f172a;
}
.event-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.event-category {
  position: absolute;
  top: 12px;
  left: 12px;
  background: #2ee56f;
  color: #000;
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 700;
}

.event-badge {
  position: absolute;
  top: 12px;
  right: 12px;
  background: rgba(0,0,0,0.75);
  color: #fff;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.2px;
}

.event-content {
  padding: 1.1rem 1.2rem 1.2rem;
  display: flex;
  flex-direction: column;
  flex: 1;
}
.event-content h3 {
  margin: 0 0 0.4rem;
  font-size: 18px;
  font-weight: 800;
}
.event-desc {
  margin: 0 0 0.9rem;
  color: var(--text-color-secondary);
  font-size: 14px;
  line-height: 1.55;
}

.event-meta {
  display: grid;
  gap: 0.6rem;
  margin-bottom: 1rem;
  font-size: 13px;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 0.55rem;
  color: var(--text-color-secondary);
}
.meta-item i {
  color: #2ee56f;
  width: 18px;
}

.event-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.75rem;
  margin-top: auto;
  padding-top: 0.9rem;
  border-top: 1px solid var(--surface-border);
}

.price {
  font-size: 16px;
  font-weight: 800;
  color: #2ee56f;
}
.price.muted {
  color: var(--text-color-secondary);
  font-weight: 700;
}

.no-events {
  text-align: center;
  padding: 2.5rem 1rem;
  color: var(--text-color-secondary);
}
.no-events i {
  font-size: 42px;
  margin-bottom: 0.75rem;
  opacity: 0.6;
}

/* Featured */
.featured-events {
  background: var(--surface-card);
  padding: 2.5rem 1rem;
  border-radius: 14px;
}
.featured-events h2 {
  font-size: 28px;
  font-weight: 900;
  margin: 0 0 1.5rem;
  text-align: center;
}
.carousel {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 1.25rem;
}
.carousel-item {
  aspect-ratio: 1;
}
.featured-card {
  position: relative;
  width: 100%;
  height: 100%;
  border-radius: 14px;
  overflow: hidden;
  cursor: pointer;
}
.featured-card img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.featured-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, transparent 55%, rgba(0, 0, 0, 0.85));
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 1rem;
  color: #fff;
  opacity: 0;
  transition: opacity 0.25s ease;
}
.featured-card:hover .featured-overlay {
  opacity: 1;
}
.featured-overlay h4 {
  margin: 0 0 0.35rem;
  font-size: 16px;
  font-weight: 800;
}
.featured-overlay p {
  margin: 0 0 0.85rem;
  font-size: 12px;
  opacity: 0.92;
}

/* Responsive */
@media (max-width: 768px) {
  .events-page {
    padding: 1.5rem 1rem 1.5rem;
  }
  .header-content {
    grid-template-columns: 1fr;
  }
  .header-visual {
    width: 110px;
    justify-self: start;
  }
  .filter-chips {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    padding-bottom: 0.25rem;
    flex-wrap: nowrap;
  }
  .events-list {
    grid-template-columns: 1fr;
  }
  .event-image {
    height: 150px;
  }
}

@media (max-width: 480px) {
  .event-desc {
    display: none;
  }
  .featured-overlay {
    opacity: 1; /* en móvil, mejor que siempre se vea */
  }
}
</style>
