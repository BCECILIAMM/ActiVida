<template>
  <section class="hero">
    <img class="hero__img" :src="src" alt="Activida runners" />
    <div class="hero__overlay"></div>

    <div class="hero__content">
      <div class="hero__cta-group">
      <Button 
        label="Empezar Ahora" 
        icon="pi pi-arrow-right"
        @click="scrollToPlans"
        class="cta-primary"
      />
      <Button 
        label="Ver Planes" 
        severity="secondary"
        @click="goToPlans"
        class="cta-secondary"
      />
      </div>

      <!-- Scroll Indicator -->
      <div class="scroll-indicator" @click="scrollDown">
      <span class="arrow-icon">
        <i class="pi pi-chevron-down"></i>
      </span>
      <span class="scroll-text">Desliza hacia abajo</span>
      </div>
    </div>
  </section>
</template>

<script setup>
import Button from "primevue/button";
import { useRouter } from "vue-router";

defineProps({
  src: { type: String, required: true },
})

const router = useRouter();

const goToPlans = () => router.push('/planes');

const scrollToPlans = () => {
  router.push('/planes');
};

const scrollDown = () => {
  window.scrollBy({
    top: window.innerHeight,
    behavior: 'smooth'
  });
};
</script>

<style scoped>
.hero {
  position: relative;
  width: 100%;
  overflow: hidden;
  background: #0b1220;

  /* QUITA esto porque crea el bloque blanco */
  margin-bottom: 170px; 

  /* Altura estable en móvil */
  min-height: 70svh;
  max-height: 100svh;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
}

.hero__img {
position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;

  /* mueve el foco para que no corte lo importante */
  object-position: 50% 25%; /* prueba 50% 20% o 50% 30% */

  z-index: 0;
  display: block;
}

.hero__overlay {
  position: absolute;
  inset: 0;
  display: block;
  background: linear-gradient(180deg, rgba(11,18,32,0.18) 0%, rgba(11,18,32,0.45) 100%);
  z-index: 1;
  pointer-events: none;
}

.hero__cta-group {
  position: relative;
  display: flex;
  gap: 16px;
  justify-content: center;
  flex-wrap: wrap;
  z-index: 5;
  width: 100%;
  padding: 0 1rem;
  margin-bottom: 12px;
}

.hero__content {
  position: relative;
  z-index: 5;
  width: 100%;
  padding: 0 1rem 32px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

:deep(.cta-primary) {
  background: linear-gradient(135deg, #2ee56f 0%, #26c95f 100%);
  border: none;
  padding: 14px 40px !important;
  font-weight: 700;
  font-size: 16px !important;
  border-radius: 8px;
  transition: all 0.3s ease;
  box-shadow: 0 8px 24px rgba(46, 229, 111, 0.3);
  cursor: pointer;
}

:deep(.cta-primary:hover) {
  transform: translateY(-3px);
  box-shadow: 0 12px 32px rgba(46, 229, 111, 0.5);
  background: linear-gradient(135deg, #3ff57e 0%, #2ee56f 100%);
}

:deep(.cta-secondary) {
  color: white !important;
  border: 2px solid white !important;
  padding: 12px 38px !important;
  font-weight: 700;
  font-size: 16px !important;
  border-radius: 8px;
  background: rgba(0, 0, 0, 0.4) !important;
  transition: all 0.3s ease;
  cursor: pointer;
}

:deep(.cta-secondary:hover) {
  background: rgba(0, 0, 0, 0.6) !important;
  border-color: #2ee56f;
  color: #2ee56f;
  box-shadow: 0 8px 24px rgba(46, 229, 111, 0.2);
}

/* Scroll Indicator */
.scroll-indicator {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  opacity: 0.6;
  transition: opacity 0.3s ease;
  z-index: 4;
}

.scroll-indicator:hover {
  opacity: 1;
}

.arrow-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border: 2px solid #2ee56f;
  border-radius: 50%;
  color: #2ee56f;
  font-size: 18px;
  animation: bounce 2s infinite;
}

.scroll-text {
  font-size: 12px;
  color: #2ee56f;
  font-weight: 500;
  white-space: nowrap;
}

@keyframes bounce {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(8px);
  }
}

@media (max-width: 1024px) {
  .hero {
    margin-bottom: 170px;
  }

  .hero__cta-group {
    margin-bottom: 12px;
  }

  /* .scroll-indicator {
    bottom: -120px;
  } */
}

@media (max-width: 768px) {
  .hero {
    margin-bottom: 170px;
  }

  .hero__cta-group {
    gap: 12px;
    margin-bottom: 12px;
  }

  /* .scroll-indicator {
    bottom: -115px;
  } */

  .arrow-icon {
    width: 36px;
    height: 36px;
    font-size: 16px;
  }

  .scroll-text {
    font-size: 11px;
  }

  :deep(.cta-primary) {
    padding: 12px 28px !important;
    font-size: 14px !important;
  }

  :deep(.cta-secondary) {
    padding: 10px 26px !important;
    font-size: 14px !important;
  }
}

@media (max-width: 480px) {
  .hero {
    margin-bottom: 170px;
  }

  .hero__cta-group {
    gap: 8px;
    margin-bottom: 12px;
  }

  /* .scroll-indicator {
    bottom: -130px;
    gap: 0.25rem;
  } */

  .arrow-icon {
    width: 32px;
    height: 32px;
    font-size: 14px;
    border-width: 1.5px;
  }

  .scroll-text {
    font-size: 10px;
  }

  :deep(.cta-primary) {
    padding: 10px 20px !important;
    font-size: 12px !important;
  }

  :deep(.cta-secondary) {
    padding: 8px 18px !important;
    font-size: 12px !important;
  }
}
</style>
